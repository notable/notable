---
title: 15 - Encrypted Notes
pinned: false
tags: [Advanced, Notebooks/Tutorial]
---

# 15 - Encrypted Notes

Notable doesn't support encrypted notes yet, but if you really need this you could make an encrypted image on your computer and put a data directory in there. 

This way the third-party program will take care of the encryption.

If there's a big demand for this perhaps support for encrypted notes can be added to Notable itself, [let us know](https://github.com/fabiospampinato/notable/issues) if you need this.
