---
title: 13 - Collaborative Editing
pinned: false
tags: [Advanced, Notebooks/Tutorial]
---

# 13 - Collaborative Editing

Notable doesn't have collaborative editing built-in, but if you put your data directory in a shared folder, like Dropbox/Google Drive/etc. then multiple people can access it and make edits at the same time.

Just make sure no 2 people are working on the same note at the same time, or some work might get lost.

This is by no means a perfect solution though.
