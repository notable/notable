---
title: 12 - Mobile Editing
pinned: false
tags: [Advanced, Notebooks/Tutorial]
---

# 12 - Mobile Editing

Notable doesn't have a mobile app yet, but there are many apps for editing Markdown files already on mobile. 

If you put your data directory into a shared folder, like Dropbox/Google Drive/etc. you could use any of those apps for editing notes or making new ones.

It wouldn't be perfect, especially if you need to change some metadata or add an attachment, but it would be ok most of the times.
