---
title: 'Wrapping up :tada:'
pinned: false
tags: [Notebooks/Tutorial]
---

# Wrapping up :tada:

Awesome, you've reached the end of the tutorial!

The next step is deleting all these tutorial notes, you can do this one-by-one, using multi-note editing, or you could just trash the whole `notes` sub-directory from your data directory.

## Feedback

If you've reached this far chances are you're considering using Notable as your main note-taking app, that's great!

Feel free to [contact us](https://github.com/fabiospampinato/notable/issues) about any issues you may encounter, any features suggestions and generally sharing your opinion about Notable and how we can improve it.

Have a wonderful day! :wave:
