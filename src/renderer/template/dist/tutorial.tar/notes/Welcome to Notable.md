---
title: 'Welcome to Notable :raising_hand_woman:'
pinned: true
attachments: [icon.png]
tags: [Notebooks/Tutorial]
---

# Welcome to Notable :raising_hand_woman:

<p align="center">
  <img src="@attachment/icon.png" width="192">
</p>

## Tutorial

Some tutorial notes have been added to your data directory.

They will guide you towards the main features Notable provides.

Once you're done exploring feel free to permanently delete them, if at any point you'd like to read them again you can re-add them to your data directory or just read the online version via the `Help -> Tutorial` menu item.
