---
title: 11 - Synchronization
pinned: false
tags: [Advanced, Notebooks/Tutorial]
---

# 11 - Synchronization

Notable doesn't have synchronization built-in, but you can have your data synchronized across computers just by putting the data directory into a shared folder, like Dropbox/Google Drive/etc.

This way the third-party service will take care of the synchronization.
